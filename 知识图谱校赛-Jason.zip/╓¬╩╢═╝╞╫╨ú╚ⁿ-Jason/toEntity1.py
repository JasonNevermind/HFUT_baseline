# -*- coding: utf-8 -*-
import pandas as pd
import re
import csv
import test

atrribute={}

def toEntity1(csvFile,entityFile,informationFile):
    print("--------数据预处理，转换数据格式------------")

    file_name = '数据集1_test.csv'  # 文件路径
    tmpread = open(file_name, 'r', newline='', encoding="utf-8")
    reader = csv.reader(tmpread, delimiter=',')
    file_name = '1.csv'  # 文件路径
    tmpwrite = open(file_name, 'w', newline='', encoding="utf-8")
    writer = csv.writer(tmpwrite, delimiter=',')
    writer.writerow(["n", "id(n)"])
    for item in reader:
        try:
            writer.writerow(item[::-1])
        except:
            print("出错")
    tmpread.close()
    tmpwrite.close()

    file_name = '数据集2_test.csv'  # 文件路径
    tmpread = open(file_name, 'r', newline='', encoding="utf-8")
    reader = csv.reader(tmpread, delimiter=',')
    file_name = '2.csv'  # 文件路径
    tmpwrite = open(file_name, 'w', newline='', encoding="utf-8")
    writer = csv.writer(tmpwrite, delimiter=',')
    writer.writerow(["n", "id(n)"])
    for item in reader:
        try:
            writer.writerow(item[::-1])
        except:
            print("出错")
    tmpread.close()
    tmpwrite.close()

    csv_data = pd.read_csv(csvFile,encoding='utf-8') #engine='python'֧�ֲ����д�����
    #print(csv_data)
    # ȡ��һ�е�������Ϣ
    row = csv_data.loc[:, ['n']].values.squeeze()
    idRow = csv_data.loc[:, ['id(n)']].values.squeeze()
    entityidTxt_root = entityFile
    inforTxt_root=informationFile
    txt_writer1 = open(entityidTxt_root + '.txt', 'w',encoding='GB18030')
    txt_writer2 = open(inforTxt_root + '.txt', 'w',encoding='GB18030')
    id=1
    for person_id,name in zip(range(len(row)),idRow):
        person = row[person_id]
        person=test.replaceURL(str(person))
        #print(person)
        name=test.decodeURL(str(name))
        #print(name)

        personinfo=person
        '''
        person=person.replace('{','')
        person = person.replace('}', '')

        personid = 0
        personname = ""
        list = person.split("','")  # ��person��������
        for information_id in range(len(list)): #��person��name����
                information = list[information_id]
                information=information.replace("'",'')
                #print(information)
                if information.split(':',1)[0] not in atrribute1:
                    atrribute1[information.split(':',1)[0]]=1
                if(information.split(':',1)[0].find('中文')!=-1 or information.split(':',1)[0].find('名称')!=-1 or information.split(':',1)[0].find('书名')!=-1):
                    if(information.split(':',1)[0].find('外文')==-1):
                        personname=information.split(':',1)[1]
                        personid=id
                    #print(personid)
        
        if personid!=0 and personname!="" :
                write_infor1 = str(personname) + "\t" + str(personid) + '\n'
                txt_writer1.write(write_infor1)#entity1
                write_infor2 = str(personid) + "\t" + str(personinfo) + '\n'
                txt_writer2.write(write_infor2)#info1
        '''        
        write_infor1 = str(name) + "\t" + str(id) + '\n'
        txt_writer1.write(write_infor1)#entity1
        write_infor2 = str(id) + "\t" + str(personinfo) + '\n'
        txt_writer2.write(write_infor2)#info1
        id+=1

    txt_writer1.close()
    txt_writer2.close()
    #print(atrribute1)
#print(atrribute)
#toEntity1("1.csv", "entity1", "information1")
