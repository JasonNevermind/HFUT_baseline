import re
from tqdm import tqdm
from toEntity1 import atrribute
'''
atrribute=['data_id','name','sex','rank_family','courtesy_name','pseudonym','birth','china_birth','death_date',
           'china_death','grave','wife_named','wife_rank','husband_info','adopt_familyrank',
           'Standalone','husband_info_attach','attach_brief','attach_brief_1','isDead','used_name','exaperatingRank',
           'shi','rank','address','era','yearsLived','education','school','work_unit','occupation','duty','ruZhui',
           'ispublic','briefBiography','originalFamily','birthPlace','phone','email','ethnicity','family','posthumousTitle',
           'description','label','name_intact','qq','contact','index_year',
           'junWang','CBDB_Address','CBDB_rushi','CBDB_guanzhi','tag','originalPlace','nationality',
           'cht_name','en_name','changedFamilyName','createdWork','jiapulogiccode','personSources']
           '''
def getSameDetail():                        #这也没找全啊。。。。。。。这baseline写的啥几把玩意。最后一个没写上
    print("-------读取同名人物信息---------")
    #读取同名人物信息  [人物姓名，id1，id2]
    same_read = open('sameBeTwo5.txt', 'r', encoding='GB18030')
    sameData=same_read.readlines()
    same_read.close()
    #读取人物信息 id  信息
    info_read1 = open('information3.txt', 'r', encoding='GB18030')
    infoData1 = info_read1.readlines()
    info_read1.close()
    # 读取人物信息 id  信息
    info_read2 = open('information4.txt', 'r', encoding='GB18030')
    infoData2 = info_read2.readlines()
    info_read2.close()
    infoData=infoData1+infoData2
    #保存人物id数组
    infoData3=[]
    for per in infoData:
        try:
            per.split('     ')
        except:
            infoData3.append('0000')
        else:
            infoData3.append(per.split('     ')[0])

    sameDetailTxt_root = 'sameDetail1'
    sameDetail_writer = open(sameDetailTxt_root + '.txt', 'w', encoding='GB18030')
    sameIndex=0
    for same in tqdm(sameData):
        sameIndex+=1

        same=same.replace('\'','')
        same = same.replace('\n', '')
        same=same.replace(' ','')
        dList=same.split(',')
        #print(dList)

        #写入同名人物姓名
        write_Info=str(dList[0])+'\n'
        #print('xingming',sameIndex,dList,len(dList),dList[0])
        #写入每个同名人物信息

        for i in range(1,len(dList)):
            #print(dList)
            entityid1 = re.findall(r"\d+", dList[i])[1]
        
            #print(entityid1)
            #print(infoData[int(entityid1)-1])
            if 'entityid1' in dList[i]:
                write_Info = write_Info + '{id:' + dList[i] + '},'+ infoData1[int(entityid1)-1].split('     ')[1]
            elif 'entityid2' in dList[i]:
                write_Info = write_Info + '{id:' + dList[i] + '},'+ infoData2[int(entityid1)-1].split('     ')[1]
            #print(write_Info)
            
          
        write_Info=write_Info+'\n'
        #print(write_Info)
        #print(write_Info)
        sameDetail_writer.write(write_Info)
    sameDetail_writer.close()
#getSameDetail()
'''
def toDeleteName():
    print("-------toDeleteName---------")
    same_read = open('sameDetail1.txt', 'r', encoding='GB18030')
    same_write = open('sameDetail2.txt', 'w', encoding='GB18030')
    sameData = same_read.readlines()
    same_read.close()
    sameData2 = []
    for i in sameData:
        if i == '\n':
            continue
        sameData2.append(i)
    samePersons = []
    index = 0
    while index < len(sameData2):
        # 每一组同名人物
        flag=0
        samePer = []
        samePer.append(sameData2[index])
        samePerName=sameData2[index].replace('\n','')
        # print(sameData2[index])
        
        if re.fullmatch(r'中文.*', samePerName) or re.fullmatch(r'.*名', samePerName) or re.fullmatch(r'.*名称', samePerName):
            flag = 1
        if flag==0:
            same_write.write(sameData2[index])
        
        index = index + 1

        while (list(sameData2[index])[0] == '{') and (index < len(sameData2)):
            if flag==1:
                print('break')
            if flag==0:
                samePer.append(sameData2[index])
                # print('==0',sameData2[index])
                same_write.write(sameData2[index])

            index = index + 1
            if index == len(sameData2):
                break
        samePersons.append(samePer)
    same_write.close()
'''
def toDeleteSpace():
    same_read = open('sameDetail1.txt', 'r', encoding='GB18030')
    same_write = open('sameDetail2.txt', 'w', encoding='GB18030')
    sameData = same_read.readlines()

    for i in sameData:
        if i.split():
            same_write.write(i)
    same_read.close()
    same_write.close()

#toDeleteSpace()

def toDeleteAttri():
    print("-------除去不必要的属性信息。保留重要的在sameDetail2中---------")
    # #除去不必要的属性信息。保留重要的在sameDetail2中
    same_read = open('sameDetail2.txt', 'r', encoding='GB18030')
    same_write = open('sameDetail3.txt', 'w', encoding='GB18030')
    sameData = same_read.readlines()
    same_read.close()
    samePersons = []
    index = 0
    while index < len(sameData):
        sameData[index] = sameData[index].replace('\n', '')

        # 每一组同名人物
        samePer = []
        samePer.append(sameData[index])
        # print(sameData[index])
        same_write.write(sameData[index] + '\n')
        index = index + 1
        while (list(sameData[index])[0] == '{') and (index < len(sameData)):
            sameData[index] = sameData[index].replace('\n', '')
            # 每一条人物信息 {id:..},属性1:..,属性2:..
            perInfor = ""
            atrriList = sameData[index].split(',')
            perInfor = perInfor + atrriList[0] + ','
            bindex = 1
            while bindex < len(atrriList):
                # 每一组属性：属性值
                atrriAndValue = atrriList[bindex]
                atrri = atrriAndValue.split(':')[0]
                atrrValue = str(atrriAndValue.split(':')[1:])
                atrrValue = atrrValue.replace('[', '')
                atrrValue = atrrValue.replace(']', '')
                atrrValue = atrrValue.replace('\'', '')
                if atrri in atrribute and atrrValue != "":
                    perInfor = perInfor + atrri + ':' + atrrValue + ','
                bindex += 1
            #print('perInfor', perInfor)
            samePer.append(perInfor)
            perInfor = perInfor + '\n'
            same_write.write(perInfor)

            index = index + 1
            if index == len(sameData):
                break
        samePersons.append(samePer)

#getSameDetail()
#toDeleteName()
#toDeleteAttri()

