# -*- coding: gbk -*-
import re
import os
import pandas as pd
import csv
import linecache

def getResult1(csvFile):
    with open("_Result_.csv","w",encoding="utf-8") as f_result:
        file_name=csvFile
        tmpread = open(file_name, 'r', newline='', encoding="utf-8")
        reader = csv.reader(tmpread, delimiter=',')

        file1 = '���ݼ�1_test.csv'  # �ļ�·��


        file2 = '���ݼ�2_test.csv'  # �ļ�·��

        '''
        file_name = 'Result.csv'  # �ļ�·��
        tmpwrite = open(file_name, 'w', newline='', encoding="utf-8")
        writer = csv.writer(tmpwrite, delimiter=',')
        '''
        for lines in reader:
            entity1=linecache.getline(file1, int(lines[0])).split(',',1)[0]
            entity2=linecache.getline(file2, int(lines[1])).split(',',1)[0]
            s=entity1+','+entity2
            #print(s)
            #writer.writerow(["����"])
            f_result.writelines(s+'\n')
    
    
#getResult1("simhash0.1.csv")