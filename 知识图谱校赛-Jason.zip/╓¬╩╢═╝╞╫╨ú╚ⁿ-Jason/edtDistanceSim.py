
import numpy as np
def edit_distance_sim(word1, word2):
    len1 = len(word1)
    len2 = len(word2)
    dp = np.zeros((len1 + 1, len2 + 1))
    for i in range(len1 + 1):
        dp[i][0] = i
        for j in range(len2 + 1):
            dp[0][j] = j
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            delta = 0 if word1[i - 1] == word2[j - 1] else 1
            dp[i][j] = min(dp[i - 1][j - 1] + delta, min(dp[i - 1][j] + 1, dp[i][j - 1] + 1))
    std=dp[len1][len2]/max(len1,len2)
    sim=1-std
    return sim

from simhash import Simhash
def simhash_demo(text1, text2):
    """
    求两文本的相似度
    :param text1:
    :param text2:
    :return:
    """
    a_simhash = Simhash(text1)
    b_simhash = Simhash(text2)
    max_hashbit = max(len(bin(a_simhash.value)), (len(bin(b_simhash.value))))
    # 汉明距离
    distince = a_simhash.distance(b_simhash)
    #print(distince)
    similar = 1 - distince / max_hashbit
    return similar

from sklearn.feature_extraction.text import CountVectorizer
from scipy.linalg import norm

def tf_similarity(s1, s2):
    def add_space(s):
        return ' '.join(list(s))
    
    # 将字中间加入空格
    s1, s2 = add_space(s1), add_space(s2)
    # 转化为TF矩阵
    cv = CountVectorizer(tokenizer=lambda s: s.split())
    corpus = [s1, s2]
    vectors = cv.fit_transform(corpus).toarray()
    # 计算TF系数
    return np.dot(vectors[0], vectors[1]) / (norm(vectors[0]) * norm(vectors[1]))



import numpy as np
from scipy.linalg import norm
from sklearn.feature_extraction.text import TfidfVectorizer
def tfidf_similarity(s1, s2):
    def add_space(s):
        return ' '.join(list(s))
    
    # 将字中间加入空格
    s1, s2 = add_space(s1), add_space(s2)
    # 转化为TF矩阵
    cv = TfidfVectorizer(tokenizer=lambda s: s.split())
    corpus = [s1, s2]
    vectors = cv.fit_transform(corpus).toarray()
    # 计算TF系数
    return np.dot(vectors[0], vectors[1]) / (norm(vectors[0]) * norm(vectors[1]))

def jacc_similarity(s1,s2):
    def add_space(s):
        return ' '.join(list(s))

    #将字中间加入空格
    s1,s2 = add_space(s1),add_space(s2)
    #转化为TF矩阵
    cv = CountVectorizer(tokenizer=lambda s:s.split())
    corpus = [s1, s2]
    vectors = cv.fit_transform(corpus).toarray()
    #求交集
    numerator = np.sum(np.min(vectors, axis=0))
    #求并集
    denominator = np.sum(np.max(vectors, axis=0))
    #计算杰卡德系数
    return 1.0*numerator / denominator
'''
a="犀鸟科(Bucerotidae)" 
b="Bucorvidae地犀鸟科"

print(edit_distance_sim(a, b))
print(tf_similarity(a, b))
print(tfidf_similarity(a, b))
'''