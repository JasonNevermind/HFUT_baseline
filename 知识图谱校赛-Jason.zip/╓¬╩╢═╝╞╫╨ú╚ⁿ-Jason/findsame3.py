# -*- coding: utf-8 -*-
from toEntity1 import atrribute
'''
atrribute=['data_id','name','sex','rank_family','courtesy_name','pseudonym','birth','china_birth','death_date',
           'china_death','grave','wife_named','wife_rank','husband_info','adopt_familyrank',
           'Standalone','husband_info_attach','attach_brief','attach_brief_1','isDead','used_name','exaperatingRank',
           'shi','rank','address','era','yearsLived','education','school','work_unit','occupation','duty','ruZhui',
           'ispublic','briefBiography','originalFamily','birthPlace','phone','email','ethnicity','family','posthumousTitle',
           'description','label','name_intact','qq','contact','index_year',
           'junWang','CBDB_Address','CBDB_rushi','CBDB_guanzhi','tag','originalPlace','nationality',
           'cht_name','en_name','changedFamilyName','createdWork','jiapulogiccode','personSources']
           '''
import pandas as pd
import re

def toEntity():#将entityid.txt,information.txt修改成需要的形式，前面加上entityid1:
    txt_read1 = open('entityid1.txt', 'r', encoding='GB18030')
    txt_read2 = open('entityid2.txt', 'r', encoding='GB18030')
    data1 = txt_read1.readlines()
    data2 = txt_read2.readlines()
    txt_write1 = open('entityid3.txt', 'w', encoding='GB18030')
    for i in data1[:-1]:
        dataList=i.split('\t')
        writeInfor='entityid1:'+str(dataList[0])+'     '+str(dataList[1])
        txt_write1.write(writeInfor)
    txt_read1.close()
    txt_write1.close()
    txt_write2 = open('entityid4.txt', 'w', encoding='GB18030')
    for i in data2[:-1]:
        dataList = i.split('\t')
        writeInfor = 'entityid2:' + str(dataList[0]) + '     ' + str(dataList[1])
        txt_write2.write(writeInfor)
    txt_read2.close()
    txt_write2.close()

   #将information修改
    txt_read1 = open('information1.txt', 'r', encoding='GB18030')
    txt_read2 = open('information2.txt', 'r', encoding='GB18030')
    data1 = txt_read1.readlines()
    data2 = txt_read2.readlines()
    txt_write1 = open('information3.txt', 'w', encoding='GB18030')
    for i in data1:
        i=i.replace('{','')
        i=i.replace('}','')
        dataList = i.split('\t')
        writeInfor = 'entityid1:' + str(dataList[0]) + '     ' + str(dataList[1])
        txt_write1.write(writeInfor)
    txt_read1.close()
    txt_write1.close()
    txt_write2 = open('information4.txt', 'w', encoding='GB18030')
    for i in data2:
        i = i.replace('{', '')
        i = i.replace('}', '')
        dataList = i.split('\t')
        writeInfor = 'entityid2:' + str(dataList[0]) + '     ' + str(dataList[1])
        txt_write2.write(writeInfor)
    txt_read2.close()
    txt_write2.close()

def findSamePerso():#从entityid中找同名的人物，存入same2.txt中  不完全同名怎么办？用相似度计算是否同一个实体
    txt_read1 = open('entityid3.txt', 'r', encoding='GB18030')
    txt_read2 = open('entityid4.txt', 'r', encoding='GB18030')
    data1 = txt_read1.readlines()
    data2 = txt_read2.readlines()
    data = data1+data2
    txt_read1.close()
    txt_read2.close()
    samePerson = []
    index = 0
    dic={}
    while index<len(data):
        data[index]=data[index].replace('\n','')
        aPerson = data[index].split()[0]
        aName = aPerson.split(':')[1]
        aPersonid = aPerson.split(':')[0]+':'+str(data[index].split()[1])
        if aName in dic.keys():#字典有同名的
            dic[aName].append(aPersonid)
        else:#加入字典
            dic[aName] = []
            dic[aName].append(aPersonid)
        index = index + 1

    for key in dic.keys():
        same = []
        if len(dic[key]) > 1:
            same.append(key)
            i = 0
            while i < len(dic[key]):
                same.append(dic[key][i])
                i = i+1
        #print(same)
        samePerson.append(same)
    #print(len(samePerson)) entityid1数据到头了25650


    print('-------------toWrit-----------')#写入同名人物
    same_writer = open('sameBeTwo1.txt', 'w',encoding='GB18030')
    for same in samePerson:
        same_writer.write(str(same)+'\n')
    same_writer.close()

    print('-------------todeletSame-----------') #same.txt中有重复行，删除后写入same2.txt
    txt_read = open('sameBeTwo1.txt', 'r', encoding='GB18030')
    data = txt_read.readlines()
    txt_read.close()
    data2 = set(data)
    data3 = list(data2)
    sameTxt_root = 'sameBeTwo2'
    same_writer = open(sameTxt_root + '.txt', 'w', encoding='GB18030')
    for per in data3:
        same_writer.write(str(per))
    same_writer.close()

    print('-------------todeletSame-----------')  # same.txt中有重复index，删除后写入same13.txt
    txt_read = open('sameBeTwo2.txt', 'r', encoding='GB18030')
    same_writer = open('sameBeTwo3.txt', 'w', encoding='GB18030')
    data = txt_read.readlines()
    txt_read.close()
    for a in data:
        a = a.replace('[', '')
        a = a.replace(']', '')
        a = a.replace('\'', '')
        a = a.replace('\n', '')
        a = a.replace(' ', '')
        aList = a.split(',')
        writeInfor = str(aList[0]) + ','
        index = 1
        indexSet = set()
        while index < len(aList):
            indexSet.add(aList[index])
            index += 1
        indexSet=str(indexSet).replace('{','')
        indexSet=indexSet.replace('}','')
        indexSet=indexSet.replace('\'','')
        writeInfor = writeInfor + str(indexSet) + '\n'
        #print(writeInfor)
        same_writer.write(writeInfor)
    same_writer.close()

    print('-------------todeletSame-----------')  # same.txt中只有一个datafrom，删掉
    txt_read = open('sameBeTwo3.txt', 'r', encoding='GB18030')
    same_writer = open('sameBeTwo4.txt', 'w', encoding='GB18030')
    data = txt_read.readlines()
    txt_read.close()
    for a in data:
        aList = a.split(',')
        # 删掉这一行
        index=1
        fromSet=set()
        while index<len(aList):
            datafrom=aList[index].split(':')[0]
            fromSet.add(datafrom)
            if len(fromSet)>=2:
                same_writer.write(a)
                break
            index +=1
    same_writer.close()

    txt_read = open('sameBeTwo4.txt', 'r', encoding='GB18030')
    same_writer = open('sameBeTwo5.txt', 'w', encoding='GB18030')
    data = txt_read.readlines()
    txt_read.close()
    for a in data:
        aList = a.split(',')
        samePerName=aList[0]
        flag=0
        '''
        if (re.fullmatch(r'中文\w*', samePerName)) or (re.fullmatch(r'\w+名', samePerName)) or (
        re.fullmatch(r'\w+名称', samePerName)):
            flag = 1
        '''
        if flag==0:
            same_writer.write(a)



#
# toEntity()
#findSamePerso()