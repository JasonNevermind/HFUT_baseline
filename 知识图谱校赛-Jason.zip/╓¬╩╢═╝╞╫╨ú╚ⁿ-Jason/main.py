# -*- coding:utf-8 -*-
import os
import findsame3
import getSameDetail
import findSamePerson1

import getResult
import getResult1
import toEntity1
if __name__ == '__main__':
    threshold = 0.382
    csvFile1 = "1.csv"
    entityFile1 = "entityid1"
    informationFile1 = "information1"
    csvFile2 = "2.csv"
    entityFile2 = "entityid2"
    informationFile2 = "information2"
    
    toEntity1.toEntity1(csvFile1,entityFile1,informationFile1)
    toEntity1.toEntity1(csvFile2,entityFile2,informationFile2)
    
    findsame3.toEntity()
    findsame3.findSamePerso()
    getSameDetail.getSameDetail()
    
    getSameDetail.toDeleteSpace()
    
    findSamePerson1.findSamePerson1(0)
    
    getResult.getResult()
    getResult1.getResult1("result.csv")
    os.remove("result.csv")


