
import re
import os
def getResult():    #������ûѡ�갡��������
    with open("select11111.txt","r",encoding='GB18030') as f,open("result.csv","w",encoding="utf-8") as f_result:
        document = f.read().split("\n\n")
        for doc in document:
            doc = doc.split("\n")
            #print(doc)
            if doc == [""]:
                continue
            elif doc[0]=="":
                doc = doc[1:]
            #print(doc)
            #print(len(doc))
            for i in range(0,len(doc),2):
                if ("entityid1" in doc[i] and "entityid2" in doc[i+1]):
                    entityid1 = re.findall("id:entityid1:(.*?)}", doc[i])[0]
                    entityid2 = re.findall("id:entityid2:(.*?)}", doc[i+1])[0]
                    #print(entityid1,entityid2)
                    f_result.writelines(str(entityid1)+","+str(entityid2)+"\n")
                elif ("entityid2" in doc[i] and "entityid1" in doc[i+1]):
                    entityid1 = re.findall("id:entityid1:(.*?)}", doc[i+1])[0]
                    entityid2 = re.findall("id:entityid2:(.*?)}", doc[i])[0]
                    #print(entityid1,entityid2)
                    f_result.writelines(str(entityid1) + "," + str(entityid2) + "\n")

#getResult()

    os.remove("select11111.txt")
    os.remove("entityid3.txt")
    os.remove("entityid4.txt")
    os.remove("information3.txt")
    os.remove("information4.txt")
    os.remove("sameBeTwo1.txt")
    os.remove("sameBeTwo2.txt")
    os.remove("sameBeTwo3.txt")
    os.remove("sameBeTwo4.txt")
    os.remove("sameBeTwo5.txt")
    os.remove("sameDetail1.txt")
    os.remove("sameDetail2.txt")


    os.remove("entityid1.txt")
    os.remove("entityid2.txt")
    os.remove("information1.txt")
    os.remove("information2.txt")
    os.remove("1.csv")
    os.remove("2.csv")



